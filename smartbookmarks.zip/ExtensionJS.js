let myLead = [];
const inputVLU = document.getElementById("input-value");
const inputBTN = document.getElementById("save-btn");
const unOrderd = document.getElementById("list-ul");
const bookmarksFromLocalStorage = JSON.parse(localStorage.getItem("myLead"));
const deleteBTN=document.getElementById("delete-btn");

deleteBTN.addEventListener("dblclick",function(){
    localStorage.clear();
    myLead=[];
    renderValue();
})

if (bookmarksFromLocalStorage) {
    myLead = bookmarksFromLocalStorage;
    renderValue();
}
inputBTN.addEventListener("click", function () {
    myLead.push(inputVLU.value);
    inputVLU.value = ""
    localStorage.setItem("myLead", JSON.stringify(myLead));
    renderValue();
})

function renderValue() {
    let listiteams = ""
    for (let i = 0; i < myLead.length; i++) {
        listiteams += `<li>
        <a target='_blank' href="  ${myLead[i]}  ">"  ${myLead[i]}  "
        </a>
        </li>`
    }
    unOrderd.innerHTML = listiteams;
}